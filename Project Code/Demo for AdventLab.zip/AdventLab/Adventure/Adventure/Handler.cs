﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Adventure
{
    class Handler
    {
        // declare lists
        public static List<Character> charList;
        public static List<Item> itemList;

        static void Main(string[] args)
        {
            // creating itemList from xml
            itemList = (
                    from e in XDocument.Load("C:/Users/Eric/Desktop/itemimport.xml").
                              Root.Elements("itemdata")
                    select new Item
                    {
                        Title = (string)e.Element("title"),
                        Desc = (string)e.Element("desc"),
                        Qnt = (int)e.Element("qnt"),
                        Weight = (int)e.Element("weight"),
                    })
                    .ToList(); // make the entire select new map + array a list

/*
            // creating charList from xml
            charList = (
                   from e in XDocument.Load("C:/Users/brent/Desktop/charimport.xml").
                             Root.Elements("chardata")
                   select new Character
                   {
                       charName = (string)e.Element("name"),
                       charPosition = (int)e.Element("position"),
                       charWeight = (int)e.Element("weight"),
                   })
                   .ToList(); // make the entire select new map + array a list

            Console.Read(); // put dbg point here
            */
        }
    }
}
