﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adventure
{
    class Level
    {
        private List<Room> map;

        public List<Room> Map { get { return map; } set { map = value; } }

        public Room GetRoom(List<Room> map, int i) { return map.ElementAt(i); }
    }
}
