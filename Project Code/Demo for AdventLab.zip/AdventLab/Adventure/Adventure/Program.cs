﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Adventure
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Item> itemList = new List<Item>();
            List<Character> charList = new List<Character>();
            List<Room> mapList = new List<Room>();

            // creating itemList from xml
            itemList = (
                    from e in XDocument.Load(@"..\..\itemimport.xml").
                        Root.Elements("itemdata")
                    select new Item
                    {
                        Title = (string)e.Element("title"),
                        Desc = (string)e.Element("desc"),
                        Qnt = (int)e.Element("qnt"),
                        Weight = (int)e.Element("weight"),
                    }).ToList(); // make the entire select new map + array a list

            // Items to Inv
            // MAP
            mapList = (
                from e in XDocument.Load(@"..\..\map.xml").
                    Root.Elements("roomsdata")
                select new Room
                {
                    Title = (string)e.Element("name"),
                    Desc = (string)e.Element("desc"),
                    Inv = new List<Item>(),
                    Exits = new int[4],
                }).ToList();
            // MUST MANUALLY ENTER EXITS

            // creating charList from xml
            charList = (
                   from e in XDocument.Load(@"..\..\charimport.xml").
                             Root.Elements("chardata")
                   select new Character
                   {
                       Name = (string)e.Element("name"),
                       Position = mapList[0],
                       CarryWeight = (int)e.Element("weight"),
                       Inv = new List<Item>(),
                   })
                   .ToList(); // make the entire select new map + array a list
            //Create main character
            Character me = charList[0];
            //Exits: Manually enter exits
            Room Cryo = mapList[0];
            Cryo.AddItem(itemList.ElementAt(3));
            mapList[0].Exits = new int[] { -1, 1, -1, -1 };

            Room Hallway = mapList[1];
            Hallway.AddItem(itemList.ElementAt(1));
            mapList[1].Exits = new int[] { 0, 2, -1, -1 };

            Room Lab = mapList[2];
            //Lab.AddItem(itemList.ElementAt(2));
            mapList[2].Exits = new int[] { 1,-1, 4, 3 };

            Room Bathroom = mapList[3];
            Bathroom.AddItem(itemList.ElementAt(4));
            mapList[3].Exits = new int[] { -1, 1, 2, -1 };

            Room Hallway2 = mapList[4];
            //Hallway2.AddItem(itemList.ElementAt(2));
            mapList[4].Exits = new int[] { -1, -1, 5, 2};

            Room Lobby = mapList[5];
            //Lobby.AddItem(itemList.ElementAt(2));
            mapList[5].Exits = new int[] { 7, 6, -1, 4 };

            Room JanitorCloset = mapList[6];
            JanitorCloset.AddItem(itemList.ElementAt(5));
            mapList[6].Exits = new int[] { 5, -1, -1, -1 };

            Room ElectricalRoom = mapList[7];
            ElectricalRoom.AddItem(itemList.ElementAt(6));
            mapList[7].Exits = new int[] { 8, 5, -1,-1};

            Room ElevatorShaft = mapList[1];
            //ElevatorShaft.AddItem(itemList.ElementAt(2));
            mapList[8].Exits = new int[] {-1, 7, -1, -1 };

            //Have player start with Sword (item 0)
            me.AddItem(itemList[0]);
            me.ViewInventory();

            if (me.Take("GUN")) Console.WriteLine("You took the GUN");
            /////game//////

            int roomIdx;
            string UserInput;

            //intro
            Console.Clear();
            // display title artwork + credits
            titleArt();

            // title - prompt user loop 
            Console.WriteLine("\n\n");
            Console.WriteLine("     info: type h for command output at any time during Cryo Break");
            Console.WriteLine("\n\n");




            string menuStart = menuLoad("\nWould you like to play? \n");
            while (menuStart == "Y" | menuStart == "YES")
            {
                string menuInput = menuCommand("What would you like to do: ");
                // questions to pass to shape depending on type of shape

                if (menuInput == "START" || menuInput == "S")
                {
                    // start program flow
                    Console.WriteLine("Loading Cryo Break....");
                    // get out of routine + make a call to XML loading
                    Console.Clear();
                    break;
                }
                else if (menuInput == "QUIT" || menuInput == "Q" || menuInput == "EXIT" || menuInput == "E")
                {
                    Console.WriteLine("Thanks for playing!");
                    System.Environment.Exit(1); // quit program safely 
                }
                else if (menuInput == "H" || menuInput == "HELP")
                {
                    // call menu help printing routine here
                    menuHelp();
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("ERROR in: title - prompt error user section");
                }

                menuStart = menuLoad("\nWould you like to play?\n");
            }


            UserInput = Console.ReadLine();
            string[] substrings = UserInput.Split(' ');
            while (UserInput.ToUpper() != "QUIT")
            {
                switch (substrings[0].ToUpper())
                {
                    case "TAKE":
                        {

                            if (me.Take(substrings[1]))
                            {
                                Console.WriteLine("You have taken: {0}", substrings[1]);
                            }
                            else
                            {
                                Console.WriteLine("Item does not exist within the room");
                            }
                            break;
                        }
                    case "REMOVE":
                        {
                            if (me.Remove(substrings[1]))
                            {
                                Console.WriteLine("Removed: {0}", substrings[1]);
                            }
                            else
                            {
                                Console.WriteLine("Item does not exist within your inventory");
                            }

                            break;
                        }
                    case "VIEW":
                        {
                            me.ViewItem(substrings[1]);
                            break;
                        }
                    case "INVENTORY":
                        {
                            me.ViewInventory();
                            break;
                        }
                    case "MOVE":
                        {
                            if (me.Move(substrings[1], out roomIdx))
                            {
                                me.Position = mapList[roomIdx];
                                Console.WriteLine("You moved to: ");
                                Console.WriteLine("{0}", mapList[roomIdx].Title);
                            }
                            else
                            {
                                Console.WriteLine("You hit a wall");
                            }

                            break;
                        }
                    case "FORAGE":
                        {
                            string answer = me.ViewRoomDesc();
                            Console.WriteLine("{0}",answer);
                            break;
                    
                        }
                    default:
                        {
                            Console.WriteLine("Command is incoherent, try again!");
                            break;
                            // invalid command
                        }
                }

                Console.WriteLine(">    ");
                UserInput = Console.ReadLine();
                substrings = UserInput.Split(' ');

            }





            // substrings[0] will have command, switch case
            // substrings[1] will have input to that command
            Console.WriteLine("Thanks for playing!");

        }

        // menu help printing routine
        static void menuHelp()
        {
            twoLine(); twoLine(); twoLine();
            Console.WriteLine("Cryo Break, Title Screen Help Menu");
            oneLine();
            Console.WriteLine("S, Start: Starts the game");
            Console.WriteLine("Q, E, Quit, Exit: Quits the program ");
            Console.WriteLine("H, Help,: Help menu (you're in this right now)");
        }

        static void oneLine()
        {
            // writes a blankline
            Console.WriteLine("\n");
        }
        static void twoLine()
        {
            // writes 2x blanklines 
            Console.WriteLine("\n\n");
        }

        static string menuLoad(string prompt)
        {
            string[] valid = new string[] { "Y", "N", "YES", "NO" };
            string menuLAnswer; // return valid hand value within list
            menuLAnswer = GetString(prompt, valid, "? Invalid answer, please re-enter");
            return menuLAnswer;
        }

        static void titleArt()
        {
            var titleArr = new[]
            {
                    @" _____                   ______                _    ",
                    @"/  __ \                  | ___ \              | |   ",
                    @"| /  \/_ __ _   _  ___   | |_/ /_ __ ___  __ _| | __",
                    @"| |   | '__| | | |/ _ \  | ___ \ '__/ _ \/ _` | |/ /",
                    @"| \__/\ |  | |_| | (_) | | |_/ / | |  __/ (_| |   < ",
                    @" \____/_|   \__, |\___/  \____/|_|  \___|\__,_|_|\_\",
                    @"             __/ |                                  ",
                    @"            |___/                                   ",
            };
            Console.WriteLine("\n\n");
            // print out each line for the title 
            foreach (string line in titleArr)
                Console.WriteLine(line);
            Console.WriteLine("by: david austin, brent rubell, and eric pires"); // credits
        }
        // handler for valid menu commands
        static string menuCommand(string prompt)
        {
            string[] valid = new string[] { "S", "START", "YES", "Y", "N", "NO", "QUIT", "Q", "EXIT", "E", "HELP", "H" };
            string menuAnswer; // return valid hand value within list
            menuAnswer = GetString(prompt, valid, "? Invalid answer, please re-enter");
            return menuAnswer;
        }

        // universal get string w. prompt, valid values and error msg
        static string GetString(string prompt, string[] valid, string error)
        {
            string response;
            bool OK = false;
            do
            {
                Console.Write(prompt);
                response = Console.ReadLine().ToUpper();
                foreach (string s in valid) if (response == s.ToUpper()) OK = true;
                if (!OK) Console.WriteLine(error);
            } while (!OK);
            return response;
        }

        static void LineBreak()
        {
            Console.WriteLine("\n");
        }

        static void TypeLine(string text)
        {
            for (int i = 0; i < text.Length; i++)
            {
                Console.Write(text[i]);
                System.Threading.Thread.Sleep(5);
            }
        }

        // via: http://stackoverflow.com/questions/3407548/c-sharp-console-set-cursor-position-to-the-last-visible-line
        static void WriteOnBottomLine(string text)
        {
            int x = Console.CursorLeft;
            int y = Console.CursorTop;
            Console.CursorTop = Console.WindowTop + Console.WindowHeight - 1;
            Console.Write(text);
            // Restore previous position
            Console.SetCursorPosition(x, y);
        }

    }
}