﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adventure
{
    class Room:Inventory
    {
        private string title;
        private string desc;
        public List<Item> inv;
        // https://www.youtube.com/watch?v=bzhj2T3Idgcs
        private int[] exits;
        
        public override List<Item> Inv { get { return inv; } set { inv = value; } }
        public string Title { get { return title; } set { title = value; } }
        public string Desc { get { return desc; } set { desc = value; } }
        public int[] Exits { get { return exits ; } set { exits = value; } }

        public Room() { Title = ""; Desc = ""; inv = new List<Item>(); ; exits = new int[4] { -1, -1, -1, -1 }; }

        public Room(string ttl, string des, List<Item> itm, int[] ext)
        {
            Title = ttl;
            Desc = des;
            inv = itm;
            exits = ext;
        }
    }
}
